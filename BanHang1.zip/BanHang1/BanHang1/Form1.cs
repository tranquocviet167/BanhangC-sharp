﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace BanHang1
{
    public partial class Form1 : Form
    {
        DataTable dt = new DataTable();
        string conn = "Data Source=DESKTOP-M84T3VE;Initial Catalog=DuLieu1;User ID=sa;Password=123";

        public Form1()
        {
            InitializeComponent();
            LoadTable();
            LoadProducts();
            dgvDanhSach.SelectionChanged += dgvDanhSach_SelectionChanged;
        }

        private void LoadTable()
        {
            using (SqlConnection con = new SqlConnection(conn))
            {
                try
                {
                    con.Open();
                    string query = @"SELECT 
                                Hang.Ma_Hang AS 'Mã Hàng', 
                                Hang.Ten_Hang AS 'Tên Hàng', 
                                ChiTietHDBan.So_Luong AS 'Số Lượng', 
                                Hang.Don_Gia_Ban AS 'Đơn Giá Bán', 
                                ChiTietHDBan.Thanh_Tien AS 'Thành Tiền'
                             FROM 
                                Hang
                             INNER JOIN 
                                ChiTietHDBan ON Hang.Ma_Hang = ChiTietHDBan.Ma_Hang";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        SqlDataAdapter adt = new SqlDataAdapter(cmd);
                        adt.Fill(dt); // Lưu trữ dữ liệu vào DataTable dt
                        dgvDanhSach.DataSource = dt;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void LoadProducts()
        {
            using (SqlConnection con = new SqlConnection(conn))
            {
                try
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand("SELECT Ten_Hang FROM dbo.Hang", con))
                    {
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            string productName = reader.GetString(0);
                            cbbSanPham.Items.Add(productName);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btnTaoMa_Click(object sender, EventArgs e)
        {
            try
            {
                string maHoaDon = SinhMaHoaDon();
                txtHDB.Text = maHoaDon;

                txtDonGia.Clear();
                txtSoLuong.Clear();
                txtThanhTien.Clear();
                cbbSanPham.Text = "";

                // Xóa dữ liệu từ DataTable
                if (dt != null)
                {
                    dt.Rows.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tạo mã hoá đơn: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string SinhMaHoaDon()
        {
            Random rand = new Random();
            int soNgauNhien = rand.Next(1000000, 9999999);
            string maHoaDonMoi = "HDB" + soNgauNhien.ToString();
            return maHoaDonMoi;
        }

        private void btnMua_Click(object sender, EventArgs e)
        {
            try
            {
                // Kiểm tra xem mã hoá đơn đã được tạo chưa
                if (string.IsNullOrEmpty(txtHDB.Text))
                {
                    MessageBox.Show("Vui lòng tạo mã hoá đơn trước khi thêm sản phẩm.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Kiểm tra xem người dùng đã nhập đầy đủ thông tin chưa
                if (string.IsNullOrEmpty(cbbSanPham.Text) || string.IsNullOrEmpty(txtSoLuong.Text))
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ thông tin sản phẩm và số lượng.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Kiểm tra xem mã hàng có bị trùng trong cùng một hoá đơn không
                string maHoaDon = txtHDB.Text;
                string maHang = GetMaHangFromComboBox(cbbSanPham.Text);
                if (IsMaHangExistsInHoaDon(maHoaDon, maHang))
                {
                    MessageBox.Show("Mã hàng đã tồn tại trong hoá đơn. Vui lòng chọn sản phẩm khác.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Thêm dữ liệu vào bảng tblChiTietHDBan
                ThemChiTietHoaDon(maHoaDon, maHang, Convert.ToInt32(txtSoLuong.Text));

                // Hiển thị lại chi tiết của hoá đơn trong DataGridView
                LoadChiTietHoaDon(maHoaDon);

                // Tính lại tổng tiền của hoá đơn và hiển thị nó trên Label
                decimal tongTien = TinhTongTienHoaDon(maHoaDon);
                lbTongTien.Text = "Tổng tiền: " + tongTien.ToString("N2");

                // Cập nhật lại lựa chọn trong ComboBox
                cbbSanPham.SelectedIndex = -1;
                cbbSanPham.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm sản phẩm vào hoá đơn: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Phương thức tính tổng tiền của hoá đơn
        private decimal TinhTongTienHoaDon(string maHoaDon)
        {
            decimal tongTien = 0;
            string query = "SELECT Thanh_Tien FROM ChiTietHDBan WHERE Ma_HDB = @MaHDB";
            using (SqlConnection con = new SqlConnection(conn))
            {
                try
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@MaHDB", maHoaDon);
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            tongTien += Convert.ToDecimal(reader["Thanh_Tien"]);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi tính tổng tiền hoá đơn: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            return tongTien;
        }

        // Phương thức để lấy mã hàng từ tên sản phẩm
        private string GetMaHangFromComboBox(string tenHang)
        {
            string query = "SELECT Ma_Hang FROM Hang WHERE Ten_Hang = @TenHang";
            using (SqlConnection con = new SqlConnection(conn))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@TenHang", tenHang);
                    return (string)cmd.ExecuteScalar();
                }
            }
        }

        // Phương thức kiểm tra xem mã hàng đã tồn tại trong hoá đơn hay chưa
        private bool IsMaHangExistsInHoaDon(string maHoaDon, string maHang)
        {
            string query = "SELECT COUNT(*) FROM ChiTietHDBan WHERE Ma_HDB = @MaHDB AND Ma_Hang = @MaHang";
            using (SqlConnection con = new SqlConnection(conn))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@MaHDB", maHoaDon);
                    cmd.Parameters.AddWithValue("@MaHang", maHang);
                    int count = (int)cmd.ExecuteScalar();
                    return count > 0;
                }
            }
        }

        // Phương thức thêm chi tiết hoá đơn vào bảng tblChiTietHDBan
        private void ThemChiTietHoaDon(string maHoaDon, string maHang, int soLuong)
        {
            string query = "INSERT INTO ChiTietHDBan (Ma_HDB, Ma_Hang, So_Luong) VALUES (@MaHDB, @MaHang, @SoLuong)";
            using (SqlConnection con = new SqlConnection(conn))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@MaHDB", maHoaDon);
                    cmd.Parameters.AddWithValue("@MaHang", maHang);
                    cmd.Parameters.AddWithValue("@SoLuong", soLuong);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void LoadChiTietHoaDon(string maHDB)
        {
            dt.Rows.Clear(); // Xóa dữ liệu trong DataTable
            string query = "SELECT * FROM ChiTietHDBan WHERE Ma_HDB = @MaHDB";
            using (SqlConnection con = new SqlConnection(conn))
            {
                try
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@MaHDB", maHDB);
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            dt.Rows.Add(reader["Ma_Hang"], reader["So_Luong"], reader["Thanh_Tien"]);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi tải dữ liệu hoá đơn: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void cbbSanPham_SelectedIndexChanged(object sender, EventArgs e)
        {
            string productName = cbbSanPham.SelectedItem.ToString();
            string query = "SELECT Don_Gia_Ban FROM Hang WHERE Ten_Hang = @TenHang";
            using (SqlConnection con = new SqlConnection(conn))
            {
                try
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@TenHang", productName);
                        object result = cmd.ExecuteScalar();
                        if (result != null)
                        {
                            txtDonGia.Text = result.ToString();
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy giá của sản phẩm.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void txtSoLuong_TextChanged(object sender, EventArgs e)
        {
            int soLuong;
            if (!int.TryParse(txtSoLuong.Text, out soLuong))
            {
                return;
            }

            string productName = cbbSanPham.SelectedItem.ToString();
            string query = "SELECT Don_Gia_Ban FROM Hang WHERE Ten_Hang = @TenHang";
            using (SqlConnection con = new SqlConnection(conn))
            {
                try
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@TenHang", productName);
                        object result = cmd.ExecuteScalar();
                        if (result != null)
                        {
                            decimal donGia = Convert.ToDecimal(result);
                            txtThanhTien.Text = (soLuong * donGia).ToString();
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy đơn giá của sản phẩm.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void txtSoLuong_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtHDB.ReadOnly = true;
            txtDonGia.ReadOnly = true;
        }

        private void dgvDanhSach_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvDanhSach.SelectedRows.Count > 0)
            {
                // Lấy dòng dữ liệu được chọn
                DataGridViewRow selectedRow = dgvDanhSach.SelectedRows[0];

                // Hiển thị thông tin tương ứng lên các điều khiển ComboBox và TextBox
                string maHang = selectedRow.Cells["Mã Hàng"].Value.ToString();
                string soLuong = selectedRow.Cells["Số Lượng"].Value.ToString();
                string donGia = selectedRow.Cells["Đơn Giá Bán"].Value.ToString();
                string thanhTien = selectedRow.Cells["Thành Tiền"].Value.ToString();

                // Hiển thị thông tin lên các điều khiển ComboBox và TextBox
                cbbSanPham.Text = GetProductNameFromMaHang(maHang);
                txtHDB.Text = maHang;
                txtSoLuong.Text = soLuong;
                txtDonGia.Text = donGia;
                txtThanhTien.Text = thanhTien;
            }
        }

        // Phương thức để lấy tên sản phẩm từ mã hàng
        private string GetProductNameFromMaHang(string maHang)
        {
            string query = "SELECT Ten_Hang FROM Hang WHERE Ma_Hang = @MaHang";
            using (SqlConnection con = new SqlConnection(conn))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@MaHang", maHang);
                    return (string)cmd.ExecuteScalar();
                }
            }
        }

        private void UpdateSoLuongChiTietHoaDon(string maHoaDon, string maHang, int soLuongMoi)
        {
            string query = "UPDATE ChiTietHDBan SET So_Luong = @SoLuongMoi WHERE Ma_HDB = @MaHDB AND Ma_Hang = @MaHang";
            using (SqlConnection con = new SqlConnection(conn))
            {
                try
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@SoLuongMoi", soLuongMoi);
                        cmd.Parameters.AddWithValue("@MaHDB", maHoaDon);
                        cmd.Parameters.AddWithValue("@MaHang", maHang);
                        cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi cập nhật số lượng: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            try
            {
                // Kiểm tra xem có dòng được chọn trong DataGridView không
                if (dgvDanhSach.SelectedRows.Count == 1)
                {
                    // Lấy thông tin từ dòng được chọn
                    DataGridViewRow selectedRow = dgvDanhSach.SelectedRows[0];
                    string maHoaDon = selectedRow.Cells["Mã Hàng"].Value.ToString();
                    string tenHang = selectedRow.Cells["Tên Hàng"].Value.ToString(); // Lấy giá trị của cột "Tên Hàng"
                    int soLuongCu = Convert.ToInt32(selectedRow.Cells["Số Lượng"].Value);

                    // Hiển thị thông tin lên các điều khiển
                    txtHDB.Text = maHoaDon;
                    cbbSanPham.SelectedItem = tenHang;
                    txtSoLuong.Text = soLuongCu.ToString();

                    // Cập nhật số lượng mới vào CSDL
                    int soLuongMoi = Convert.ToInt32(txtSoLuong.Text);
                    string maHang = GetMaHangFromComboBox(tenHang); // Lấy mã hàng từ tên hàng
                    UpdateSoLuongChiTietHoaDon(maHoaDon, maHang, soLuongMoi);
                    LoadChiTietHoaDon(maHoaDon); // Cập nhật dữ liệu sau khi sửa số lượng

                    MessageBox.Show("Đã cập nhật số lượng thành công.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Vui lòng chọn một chi tiết hoá đơn để sửa.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi sửa số lượng: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



    }
}
